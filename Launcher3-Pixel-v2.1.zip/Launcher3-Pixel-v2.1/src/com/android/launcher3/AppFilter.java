package com.android.launcher3;

import android.content.ComponentName;

public class AppFilter {

    public boolean shouldShowApp(ComponentName app) {
        return true;
    }
}
